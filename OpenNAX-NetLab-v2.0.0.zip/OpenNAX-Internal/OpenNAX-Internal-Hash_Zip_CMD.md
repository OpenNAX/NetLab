Command to create the zip (on pwd)

zip -r OpenNAX-NetLab-v2.0.0.zip . -x "*.git*"
shasum -a 256 OpenNAX-NetLab-v2.0.0.zip > OpenNAX-NetLab-v2.0.0.zip.sha256